use amazon;

SELECT * FROM sales;

ALTER TABLE sales
ADD COLUMN timeofday VARCHAR(10);

UPDATE sales
SET timeofday = CASE
    WHEN HOUR(time) BETWEEN 5 AND 11 THEN 'Morning'
    WHEN HOUR(time) BETWEEN 12 AND 16 THEN 'Afternoon'
    ELSE 'Evening'
END;



ALTER TABLE sales
ADD COLUMN dayname VARCHAR(10);

UPDATE sales
SET dayname = date_format(Date, '%a');

ALTER TABLE sales
ADD COLUMN Monthname VARCHAR(10);

UPDATE Sales
SET Monthname = date_format(Date, '%b');


SELECT COUNT(*) FROM sales;

SHOW COLUMNS FROM sales;



# QUE 1:  What is the count of distinct cities in the dataset?

select count(distinct city) as distinct_city from sales;

# comment: in amazon.sales table we have 3 unique cities (i.e Mandalay, Yangon and Naypyitaw)


# QUE 2:  For each branch, what is the corresponding city?

select  distinct branch , city from sales;

# comment: Branch A correspond to Yangon , Branch b correspond to Mandalay, Branch c correspond to Naypyitaw


# QUE3: What is the count of distinct product lines in the dataset?

Select count(distinct Product_line) as distinct_product_line from sales;

# comment:There are total 6 Distinct_product_line in sales Table 

# QUE4: Which payment method occurs most frequently?

SELECT Payment, count(payment) as Total_count FROM sales group by payment order BY Payment DESC;

# comment: EWallet payment method occurs most frequently with total_count of 345

# QUE5: Which product line has the highest sales?

SELECT Product_line, sum(Quantity) as Total_sum from sales group by product_line order by Total_sum desc;

# comment: Electronic accessories Product line has the highest sales value from sales table

# QUE6:How much revenue is generated each month?


select Monthname, sum(total) as revenue from sales group by monthname ;

# comment:jan=116291.86800000005,  Feb=97219.37399999997,    Mar=109455.50700000004

# QUE7:In which month did the cost of goods sold reach its peak?

select Monthname,sum(cogs) as total_cogs from sales group by Monthname order by total_cogs desc;

# comment: month of jan cogs got its peak value.

# QUE8:Which product line generated the highest revenue?

SELECT Product_line ,sum(total) as revenue from sales group by product_line order by revenue;

# comment: Health and beauty type of product line generated  highest revenue 


# QUE9 :In which city was the highest revenue recorded?

SELECT city ,sum(total) as revenue from sales group by city order by revenue desc;

# comment: Naypyitaw has the highest revenue recorded.

# QUE10 : Which product line incurred the highest Value Added Tax?

SELECT Product_line,sum(Tax_5) as total_tax from sales group by Product_line order by total_tax desc;

# comment:Food and beverages product line has the highest value added tax with 2673.563999

# QUE 11: For each product line, add a column indicating "Good" if its sales are above average, otherwise "Bad."

SELECT product_line, SUM(total) AS total_sales,
    CASE
        WHEN SUM(total) > (SELECT AVG(total_sales) FROM (
            SELECT SUM(total) AS total_sales
            FROM sales
            GROUP BY product_line
        ) AS avg_sales_subquery) THEN 'Good'
        ELSE 'Bad'
    END AS sales_status
FROM sales GROUP BY product_line;

/*
 comment:
Health and beauty	49193.739000000016	Bad
Electronic accessories	54337.531500000005	Good
Home and lifestyle	53861.91300000001	Good
Sports and travel	55122.826499999996	Good
Food and beverages	56144.844000000005	Good
Fashion accessories	54305.895	Good
*/

# que 12:Identify the branch that exceeded the average number of products sold.
WITH BranchTotalSales AS (
    SELECT branch,SUM(quantity) AS total_products_sold
    FROM sales GROUP BY branch
),
OverallAvgSales AS (
    SELECT AVG(total_products_sold) AS avg_total_products_sold
    FROM BranchTotalSales
)
SELECT branch,total_products_sold
FROM BranchTotalSales
WHERE total_products_sold > (SELECT avg_total_products_sold FROM OverallAvgSales);

# comment: A brach has exceeded the aveage number of product sold. 

# que 13: Which product line is most frequently associated with each gender?

WITH ProductLineCounts AS (
    SELECT gender,product_line,
        COUNT(*) AS product_line_count
    FROM sales GROUP BY gender, product_line
),
RankedProductLines AS (
    SELECT gender,product_line,product_line_count,
        ROW_NUMBER() OVER (PARTITION BY gender ORDER BY product_line_count DESC) AS position
    FROM ProductLineCounts
)
SELECT gender, product_line, product_line_count
FROM RankedProductLines WHERE position = 1;

# comment :Fashion accessories has the more associated with female and Health and beauty associated with male gender.  

# que14: Calculate the average rating for each product line.

select product_line,avg(rating) as avg_rating  from sales group by product_line;

/*comment:
Health and beauty	7.003289473684212
Electronic accessories	6.92470588235294
Home and lifestyle	6.8375
Sports and travel	6.916265060240964
Food and beverages	7.113218390804598
Fashion accessories	7.029213483146067
*/

# que 15: Count the sales occurrences for each time of day on every weekday.

SELECT dayname,timeofday, COUNT(*) AS sales_count
FROM sales
GROUP BY dayname, timeofday ORDER BY dayname, timeofday;

/* comment:
Fri	Afternoon	68
Fri	Evening	42
Fri	Morning	29
Mon	Afternoon	64
Mon	Evening	40
Mon	Morning	21
Sat	Afternoon	69
Sat	Evening	67
Sat	Morning	28
Sun	Afternoon	59
Sun	Evening	52
Sun	Morning	22
Thu	Afternoon	61
Thu	Evening	44
Thu	Morning	33
Tue	Afternoon	62
Tue	Evening	60
Tue	Morning	36
Wed	Afternoon	71
Wed	Evening	50
Wed	Morning	22
*/

#que16: Identify the customer type contributing the highest revenue.

select customer_type,sum(total) as revenue from sales group by customer_type order by revenue desc;

# member customer type has the highest revenue with no 164223.44

#que17:Determine the city with the highest VAT percentage.

select city,sum(tax_5) as total_vat from sales group by city order by total_vat desc;

# comment : naypyitaw city has the highest VAT percentage (5265.176)

#que18:Identify the customer type with the highest VAT payments.

select customer_type,sum(tax_5) as total_vat from sales group by customer_type order by total_vat desc;

# comment:member type of customer has a highest vat payments.

#que19:What is the count of distinct customer types in the dataset?

select count(distinct customer_type) as unique_customer_type from sales ;

# comment: This indicates that there are 2 distinct customer types in the dataset. 


# que 20: What is the count of distinct payment methods in the dataset?

select count(distinct payment) as unique_payments from sales;

#comment: This indicates that there are 3 distinct payment methods in the dataset 


# que21: Which customer type occurs most frequently?
select customer_type, count(customer_type) as unique_customer_type from sales 
group by customer_type order by unique_customer_type desc;

# comment : This indicates that the "Member" customer type occurs most frequently.

# que22: Identify the customer type with the highest purchase frequency.

SELECT customer_type,COUNT(*) AS purchase_frequency FROM sales
GROUP BY customer_type ORDER BY purchase_frequency DESC ;

#comment: This indicates that the "Member" customer type has the highest purchase frequency. 

# que 23:Determine the predominant gender among customers.

select gender,count(gender) from sales group by gender;
# comment:This indicates that "Female" is the predominant gender among customers.

#que 24:Examine the distribution of genders within each branch.
select branch,gender,count(gender) as total_gender from sales group by branch ,gender order by branch,total_gender desc ;

/*comment: 
A	Male	179
A	Female	161
B	Male	170
B	Female	162
C	Female	178
C	Male	150
*/

# que 25: Identify the time of day when customers provide the most ratings.

select timeofday ,count(Rating) as total_count from sales group by timeofday order by total_count desc;

#comment: afternoon time customers will  provide the most rating. 

# que26: Determine the time of day with the highest customer ratings for each branch.


WITH RatingCounts AS (
    SELECT branch, timeofday ,COUNT(rating) AS rating_count
    FROM sales GROUP BY branch, timeofday           
),
RankedRatings AS (
    SELECT branch,timeofday,rating_count,ROW_NUMBER() OVER (PARTITION BY branch ORDER BY rating_count DESC) AS position
    FROM RatingCounts
)
SELECT branch, timeofday, rating_count
FROM RankedRatings  WHERE position = 1 ORDER BY branch;

# comment: in all 3 braches afternoon time has the highest customer rating . 

#que 27:Identify the day of the week with the highest average ratings.

select dayname,avg(rating) as avg_rating from sales group by dayname order by avg_rating desc limit 1 ;

#comment: on monday we have highest average raitings. 

#que28:Determine the day of the week with the highest average ratings for each branch.

WITH DayOfWeekRatings AS (
    SELECT
        branch,
       dayname,
        Avg(rating) AS avg_rating
    FROM sales
    GROUP BY branch, dayname
),
RankedRatings AS (
    SELECT
        branch,
        dayname,
        avg_rating,
        ROW_NUMBER() OVER (PARTITION BY branch ORDER BY avg_rating DESC) AS position
    FROM DayOfWeekRatings
)
SELECT
    branch,
    dayname,
    avg_rating
FROM RankedRatings
WHERE position = 1
ORDER BY branch;



